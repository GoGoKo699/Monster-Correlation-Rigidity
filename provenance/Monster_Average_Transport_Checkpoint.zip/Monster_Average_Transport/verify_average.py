#!/usr/bin/env python3
"""Exact scalar checks for average Monster transport and synchronization.

Standard library only. This checks scalar identities and bounds, not the full
Monster tensor, the VOA classification, independent proof review, or novelty.
Checks remain active under python -O and -OO.
"""
from __future__ import annotations
import hashlib
import json
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path

PRIOR_HASH = '5bf8a6ae9106e8126179d466c326cacb3b485e3dcb89dd761a07905a48daaf94'
CHECKS: list[str] = []


def require(ok: bool, label: str) -> None:
    if not ok:
        raise RuntimeError('Check failed: ' + label)
    CHECKS.append(label)


def add(a: tuple[F, ...], b: tuple[F, ...]) -> tuple[F, ...]:
    z = [F(0)] * max(len(a), len(b))
    for i, x in enumerate(a): z[i] += x
    for i, x in enumerate(b): z[i] += x
    while len(z) > 1 and not z[-1]: z.pop()
    return tuple(z)


def scale(a: tuple[F, ...], c: F) -> tuple[F, ...]:
    return add(tuple(c*x for x in a), (F(0),))


def mul(a: tuple[F, ...], b: tuple[F, ...]) -> tuple[F, ...]:
    z = [F(0)] * (len(a)+len(b)-1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): z[i+j] += x*y
    return add(tuple(z), (F(0),))


def evaluate(p: tuple[F, ...], x: F) -> F:
    out = F(0)
    for c in reversed(p): out = out*x+c
    return out


def dec(x: F | int) -> Decimal:
    x = F(x)
    return Decimal(x.numerator) / Decimal(x.denominator)


def main() -> None:
    prior = Path(__file__).resolve().parent/'previous'/'Monster_Global_Rounding_Checkpoint.zip'
    require(hashlib.sha256(prior.read_bytes()).hexdigest() == PRIOR_HASH,
            'Previous global checkpoint is byte-identical')
    d, kappa = 196883, F(13858, 3)
    m2, gap = F(2116, 141), F(11161, 13858)
    reality = F(48011041, 787532)
    require(m2 == F(46)**2 / 141, 'Squared cubic maximum')
    require(m2 > F(19,5)**2 and F(226)**2/4893 < F(33,10)**2,
            'Critical-value gap exceeds one half')
    require(F(84,47) > 1, 'Axes separated by more than twice radius one half')

    # q=1-r^2/2. The non-cubic-remainder part of the radial deficit.
    q = (F(1),F(0),F(-1,2))
    q2, q3 = mul(q,q), mul(mul(q,q),q)
    base = add(scale(add((F(1),),scale(q3,F(-1))),F(46)),
               scale(mul(q,add((F(1),),scale(q2,F(-1)))),F(-33)))
    expected = (F(0),F(0),F(36),F(0),F(-39,4),F(0),F(13,8))
    require(base == expected, 'Exact radial polynomial expansion')
    p = (F(36),F(-46),F(-39,4),F(23,2),F(13,8))
    require(evaluate(p,F(1,2)) == F(1549,128), 'Radial lower polynomial at one half')
    require(F(1549,128)**2 - 141 == F(89257,16384) > 0,
            'Radial growth coefficient exceeds one')
    deriv_bound = -46+F(69,8)+F(13,16)
    require(deriv_bound == F(-585,16) < 0, 'Radial lower polynomial is decreasing')
    require(F(1,2)**2 == F(1,4) < F(1,2), 'Superlevel localization threshold one quarter')
    require(F(4)/F(1,4) == 16, 'Bad-match completion coefficient')
    require(F(1) <= 16, 'Same completion coefficient covers good matches')

    upper_constant, upper_quadratic = F(36,23), F(141,184)
    r_star = 1/(2*upper_quadratic)
    require(r_star == F(92,141), 'Global upper-deficit quadratic vertex')
    maximum = upper_constant + r_star-upper_quadratic*r_star*r_star
    require(maximum == F(6134,3243) < 2, 'Global upper deficit is less than 2M times distance squared')
    require(F(3,2)+F(3,46) == upper_constant, 'Upper deficit quadratic coefficient')
    require(F(3,4)+F(3,184) == upper_quadratic, 'Upper deficit quartic coefficient')
    require(F(32)**2*m2/gap**2 < F(154)**2,
            'All-error real transport coefficient is less than 154')
    require(F(1,2)*F(1,2) == F(1,4), 'Transport lower loss coefficient one quarter')

    sqrt_k_upper, m_upper = F(781,100), F(1937,500)
    inverse_gap_upper, sqrt_8m_upper = F(2229,1000), F(557,100)
    require(reality < sqrt_k_upper**2, 'sqrt(K_R) below 7.81')
    require(m2 < m_upper**2, 'M below 3.874')
    require(F(4)/gap < inverse_gap_upper**2, '2/sqrt(Delta) below 2.229')
    require(8*m_upper < sqrt_8m_upper**2, 'sqrt(8M) below 5.57')
    complex_root_upper = sqrt_k_upper+sqrt_8m_upper*(3*sqrt_k_upper+inverse_gap_upper)
    require(complex_root_upper**2 < 23000, 'Global complex transport coefficient below 23000')

    eigenvalues_c = [F(1),F(2697,13858),F(155,13858),F(-7,13858),F(-845,13858),F(1,13858)]
    require(max(eigenvalues_c[1:]) == 1-gap,
            'Largest non-scalar eigenvalue of partial transpose is 1-Delta')
    require(eigenvalues_c.count(F(1)) == 1, 'Scalar eigenvalue is distinct')
    require(F(23000)*(1+inverse_gap_upper)**2 < 240000,
            'Different-device transport coefficient below 240000')
    require(F(154,10**6) < F(1241,100000)**2,
            'Real example RMS is below 0.01241')
    require(F(154,10**6)/F(1,10)**2 == F(154,10000), 'Real example tail at most 1.54 percent')
    require(F(23000,10**8) < F(1517,100000)**2, 'Complex example RMS is below 0.01517')
    require(F(23000,10**8)/F(1,10)**2 == F(23,1000), 'Complex example tail at most 2.3 percent')

    with localcontext() as ctx:
        ctx.prec=55
        m=dec(m2).sqrt(); g=dec(gap); k=dec(reality)
        a0=3*k.sqrt()+2/g.sqrt()
        complex_coefficient=(k.sqrt()+(8*m).sqrt()*a0)**2
        numbers = {
            'dimension':d,'kappa':str(kappa), 'M':str(m),
            'parent_gap':str(g),'real_transport_coefficient':str(32*m/g),
            'small_error_real_transport_coefficient':str(16*m/g),
            'complex_transport_coefficient':str(complex_coefficient),
            'synchronization_distance_coefficient':str(2/g.sqrt()),
            'unequal_to_equal_rejection_coefficient':str((1+2/g.sqrt())**2),
            'rational_upper_complex_root':str(complex_root_upper),
        }
    print(json.dumps({'status':'PASS within stated scope','check_count':len(CHECKS),
        'checks':CHECKS,'constants':numbers,
        'scope':'Exact scalar identities, rational constant bounds, and prior archive hash only',
        'full_Monster_tensor_constructed':False,'independent_proof_review':False,
        'novelty_established':False},sort_keys=True,indent=2))

if __name__ == '__main__': main()
