#!/usr/bin/env python3
"""Replay all four earlier verifiers without editing their source archives."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile

PRIOR_HASH='5bf8a6ae9106e8126179d466c326cacb3b485e3dcb89dd761a07905a48daaf94'


def need(ok: bool, label: str) -> None:
    if not ok: raise RuntimeError(label)


def unpack(source: Path, target: Path) -> Path:
    with ZipFile(source) as z:
        for member in z.infolist():
            p=Path(member.filename)
            need(not p.is_absolute() and '..' not in p.parts,'Unsafe archive member')
            need((member.external_attr>>16)&0o170000!=0o120000,'Archive contains a symlink')
        z.extractall(target)
    roots=list(target.iterdir())
    need(len(roots)==1 and roots[0].is_dir(),'Expected one archive root')
    root=roots[0]
    manifest=json.loads((root/'manifest.json').read_text())
    for rec in manifest['files']:
        p=Path(rec['path'])
        need(not p.is_absolute() and '..' not in p.parts,'Unsafe manifest path')
        raw=(root/p).read_bytes()
        need(len(raw)==rec['bytes'],'Manifest size mismatch: '+str(p))
        need(hashlib.sha256(raw).hexdigest()==rec['sha256'],'Manifest hash mismatch: '+str(p))
    return root


def replay(root: Path, script: str, expected: str) -> dict:
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    done=subprocess.run([sys.executable,script],cwd=root,env=env,capture_output=True,timeout=35)
    need(done.returncode==0,f'{script} failed: '+done.stderr.decode(errors='replace'))
    old=(root/expected).read_bytes()
    need(done.stdout==old,f'{script} report differed from preserved report')
    return {'script':script,'expected_report':expected,'exit_code':done.returncode,
            'byte_identical':True,'stdout_sha256':hashlib.sha256(done.stdout).hexdigest()}


def main() -> None:
    source=Path(__file__).resolve().parent/'previous'/'Monster_Global_Rounding_Checkpoint.zip'
    need(hashlib.sha256(source.read_bytes()).hexdigest()==PRIOR_HASH,'Previous archive hash mismatch')
    with tempfile.TemporaryDirectory(prefix='monster_replay_') as temp:
        r=Path(temp)
        global_root=unpack(source,r/'global')
        pair_root=unpack(global_root/'previous'/'Monster_Bipartite_Correlations_Checkpoint.zip',r/'pair')
        reports=[replay(global_root,'verify_global.py','verification_global.json'),
                 replay(pair_root,'verify_exact.py','verification_exact.json'),
                 replay(pair_root,'verify_toy.py','verification_toy.json'),
                 replay(pair_root/'previous','verify_monster_local.py','verification.json')]
    print(json.dumps({'status':'PASS within preserved computational scopes',
                      'archive_sha256':PRIOR_HASH,'verifiers':reports,
                      'independent_proof_review':False},sort_keys=True,indent=2))

if __name__=='__main__':main()
