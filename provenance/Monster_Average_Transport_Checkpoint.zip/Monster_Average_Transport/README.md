# Monster correlation research: average transport and synchronization

Read `Monster_Average_Transport_and_Synchronization.md` first.

This checkpoint proves, subject to its stated established and earlier-derived inputs, an all-error **average axis-ensemble transport** bound. It does not replace that metric by distance to one Monster operation. It also treats two different fixed unitaries and derives a global synchronization inequality and the exact product-unitary stabilizer.

Run:

```sh
python verify_manifest.py
python verify_average.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python verify_average_toy.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python rerun_previous.py
```

The first script uses only the Python standard library. The small toy script and one prior verifier require NumPy. No large simulation, internet request, or Monster-sized array is used.

Independent proof review, novelty, efficient probe access, and useful global rounding to one Monster gate remain unestablished. The original preceding checkpoint is preserved byte-for-byte under `previous/`.
