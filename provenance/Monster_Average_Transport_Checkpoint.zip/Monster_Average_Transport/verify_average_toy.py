#!/usr/bin/env python3
"""Small deterministic tensor/transport/synchronization checks, not the Monster.

Uses only simplex tensors in real dimensions 3 and 4. Exact assignments enumerate
at most 5!=120 permutations; largest matrix dimension is 64. Requires NumPy.
"""
from __future__ import annotations
import itertools
import json
import math
import numpy as np


def need(ok: bool, label: str) -> None:
    if not ok: raise RuntimeError(label)


def close(a, b, label: str, tolerance: float=2e-9) -> float:
    error=float(np.linalg.norm(np.asarray(a)-np.asarray(b)))
    need(error<tolerance, f'{label}: error={error}')
    return error


def exp_i(h: np.ndarray, t: float=1.0) -> np.ndarray:
    v,b=np.linalg.eigh(h)
    return (b*np.exp(1j*t*v))@b.conj().T


def run(n: int) -> dict:
    d=n-1
    b=np.zeros((n,d))
    for j in range(d):
        b[:j+1,j]=1/math.sqrt((j+1)*(j+2))
        b[j+1,j]=-(j+1)/math.sqrt((j+1)*(j+2))
    axes=b*math.sqrt(n/(n-1))
    tensor=np.einsum('ai,aj,ak->ijk',b,b,b)
    kap=(n-2)/n
    m=(n-2)/math.sqrt(n*(n-1))
    w=tensor.reshape(d,d*d).T/math.sqrt(kap)
    p=w@w.T
    tau=tensor.reshape(-1)/math.sqrt(d*kap)
    channel=sum(np.kron(x,x) for x in tensor)/kap
    swap=np.eye(d*d).reshape(d,d,d,d).transpose(1,0,2,3).reshape(d*d,d*d)
    c=channel@swap
    evals=np.linalg.eigvalsh(channel)
    parent_gap=1-max(abs(x) for x in evals if abs(x-1)>1e-9)
    cevals=np.linalg.eigvalsh(c)
    sync_gap=1-max(x for x in cevals if abs(x-1)>1e-9)
    need(np.count_nonzero(abs(cevals-1)<1e-9)==1, 'Simple scalar eigenspace')
    checks={
        'isometry':close(w.T@w,np.eye(d),'isometry'),
        'frame':close(axes.T@axes/n,np.eye(d)/d,'tight frame'),
        'orbit_cubic_moment':close(np.einsum('ai,aj,ak->ijk',axes,axes,axes)/n,
                                  m/(d*kap)*tensor,'cubic moment'),
        'partial_transpose':close(p.reshape(d,d,d,d).transpose(0,3,2,1).reshape(d*d,d*d),c,'partial transpose'),
    }
    permutations=list(itertools.permutations(range(n)))
    rng=np.random.default_rng(920026+n)
    x=rng.normal(size=(d,d))
    skew=x-x.T
    rotation_generator=1j*skew
    rotation_generator/=np.linalg.norm(rotation_generator,ord=2)
    # Identity, minus identity, an exact simplex permutation, and several rotations.
    psym=np.roll(np.eye(n),1,axis=0)
    operations=[np.eye(d),-np.eye(d),b.T@psym@b]
    operations += [exp_i(rotation_generator,t).real for t in (0.002,0.08,0.4,1.1,2.4)]
    transport=[]
    for o in operations:
        close(o.T@o,np.eye(d),'orthogonality')
        alpha=float(np.dot(tau,np.kron(np.kron(o,o),o)@tau))
        chosen=o if alpha>=0 else -o
        points=axes@chosen.T
        values=np.einsum('ijk,ai,aj,ak->a',tensor,points,points,points)
        deficits=m-values
        close(float(deficits.mean()),m*(1-abs(alpha)),'average deficit')
        costs=((points[:,None,:]-axes[None,:,:])**2).sum(axis=2)
        match={}
        for i in range(n):
            if deficits[i]<.25-1e-10:
                j=int(np.argmin(costs[i]))
                need(costs[i,j]<.25+1e-9,'Toy localizes good point within one half')
                need(costs[i,j]<=deficits[i]+1e-9,'Toy local growth coefficient one')
                need(j not in match.values(),'Good-match injection')
                match[i]=j
        missing_src=[i for i in range(n) if i not in match]
        missing_dst=[j for j in range(n) if j not in match.values()]
        match.update(zip(missing_src,missing_dst))
        completion=float(sum(costs[i,match[i]] for i in range(n))/n)
        need(completion<=16*max(0,float(deficits.mean()))+1e-8,'Completed matching bound')
        best=math.inf
        for sign in (1,-1):
            cc=((sign*points[:,None,:]-axes[None,:,:])**2).sum(axis=2)
            best=min(best,min(sum(cc[i,perm[i]] for i in range(n))/n for perm in permutations))
        need(best<=completion+1e-9,'Exact assignment is no worse than completion')
        o2=np.kron(o,o)
        eps=float(1-np.trace(p@o2@p@o2.T)/d)
        cubic=1-alpha*alpha
        need(eps<=cubic+1e-9 and cubic<=2*eps/parent_gap+1e-9,'Pair/cubic comparison')
        transport.append({'alpha':alpha,'mean_deficit':float(deficits.mean()),
                          'completed_cost':completion,'optimal_cost':best,
                          'pair_rejection':eps})
    sync=[]
    for t in (0.,0.02,0.3,1.,2.):
        z=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
        h=(z+z.conj().T)/2
        h/=np.linalg.norm(h,ord=2)
        z2=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
        h2=(z2+z2.conj().T)/2
        h2/=np.linalg.norm(h2,ord=2)
        u=exp_i(h,.6);v=u@exp_i(h2,t)
        zz=np.kron(u,v)
        rho=zz@p@zz.conj().T/d
        eps=float(1-np.trace(p@rho).real)
        dd=u.conj().T@v
        direct=float(np.trace(swap@rho).real)
        formula=float(np.vdot(dd.reshape(-1),c@dd.reshape(-1)).real/d)
        error=close(direct,formula,'Swap expectation equals C-Rayleigh quotient')
        trace_abs=abs(np.trace(dd))/d
        lower=sync_gap/2*(1-trace_abs**2)
        need(eps+1e-9>=(1-direct)/2,'Antisymmetric subspace is rejected')
        need((1-direct)/2+1e-9>=lower,'Non-scalar C spectrum gives synchronization')
        relative2=max(0.,2*(1-trace_abs))
        need(relative2<=4*eps/sync_gap+1e-9,'Relative distance bound')
        uu=np.kron(u,u)
        equal_eps=float(1-np.trace(p@uu@p@uu.conj().T).real/d)
        need(math.sqrt(max(0,equal_eps))<=math.sqrt(max(0,eps))+math.sqrt(relative2)+1e-8,
             'Unequal-to-equal leakage triangle bound')
        sync.append({'unequal_rejection':eps,'relative_distance_squared':relative2,
                     'spectral_lower_bound':float(lower),'swap_contraction_error':error})
    return {'dimension':d,'axis_count':n,'permutations_enumerated_per_sign':len(permutations),
            'largest_matrix_dimension':d**3,'identity_errors':checks,
            'parent_gap':float(parent_gap),'synchronization_gap':float(sync_gap),
            'transport_checks':transport,'synchronization_checks':sync,'passed':True}


def main() -> None:
    print(json.dumps({'status':'PASS within stated scope','numpy_version':np.__version__,
                      'scope':'Small non-Monster tensor contractions and finite assignments only',
                      'Monster_specific_bounds_numerically_tested':False,
                      'toys':[run(4),run(5)]},sort_keys=True,indent=2))

if __name__=='__main__':main()
