#!/usr/bin/env python3
"""Check the checkpoint payload against manifest.json; no network access."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    entries = manifest["files"]
    expected = {entry["path"] for entry in entries}
    if len(expected) != len(entries):
        raise RuntimeError("Duplicate manifest paths")
    actual = {
        str(path.relative_to(root))
        for path in root.rglob("*")
        if path.is_file()
        and path.name != "manifest.json"
        and "__pycache__" not in path.relative_to(root).parts
    }
    if actual != expected:
        raise RuntimeError(f"Payload mismatch: missing={expected-actual}, extra={actual-expected}")
    for entry in entries:
        path = root / entry["path"]
        if not path.resolve().is_relative_to(root):
            raise RuntimeError("Manifest path escapes checkpoint directory")
        data = path.read_bytes()
        if len(data) != entry["bytes"]:
            raise RuntimeError(f"Length mismatch: {entry['path']}")
        if hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise RuntimeError(f"SHA256 mismatch: {entry['path']}")
    print(json.dumps({"status": "PASS", "verified_payload_files": len(entries)}, sort_keys=True))


if __name__ == "__main__":
    main()
