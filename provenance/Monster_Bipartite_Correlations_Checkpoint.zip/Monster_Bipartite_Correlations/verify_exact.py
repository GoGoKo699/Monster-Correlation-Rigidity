#!/usr/bin/env python3
"""Exact checks for the Monster bipartite-correlation checkpoint.

Python 3.10+, standard library only; no network or Monster-size arrays.
The Monster-specific checks are conditional on the cited trace identities.
Small integer tensors check index contractions independently of those inputs.
"""
from __future__ import annotations
from fractions import Fraction as Q
from itertools import product, combinations_with_replacement, permutations
import json
import math


def need(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def mm(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]


def tr(a):
    return sum(a[i][i] for i in range(len(a)))


def eye(n):
    return [[int(i == j) for j in range(n)] for i in range(n)]


def tensor_checks(t):
    n = len(t)
    ls = t
    def f(x):
        terms = [mm(mm(li, x), li) for li in ls]
        return [[sum(z[a][b] for z in terms) for b in range(n)] for a in range(n)]
    s = Q(2, 3)
    rs = []
    for a in range(n):
        r = [[Q(0) for _ in range(n+1)] for _ in range(n+1)]
        r[0][a+1] = r[a+1][0] = s
        for b, c in product(range(n), repeat=2):
            r[b+1][c+1] = t[a][b][c]
        rs.append(r)
    # The general scalar-block subtraction, before substituting Monster data.
    def mu_inner(a,b,c,e):
        return sum(t[a][b][j]*t[c][e][j] for j in range(n))
    for a,b,c,e in product(range(n),repeat=4):
        rhs = tr(mm(mm(mm(ls[a],ls[b]),ls[c]),ls[e]))
        rhs += 2*s*s*(mu_inner(a,b,c,e)+mu_inner(a,e,b,c))
        rhs += s**4*(int(a==b)*int(c==e)+int(a==e)*int(b==c))
        need(tr(mm(mm(mm(rs[a],rs[b]),rs[c]),rs[e])) == rhs,
             'Four-factor scalar-block subtraction failed')
    # F^2 matrix coefficient, checked without any Monster trace identities.
    for p,q in product(range(n),repeat=2):
        x = [[int(i==p and j==q) for j in range(n)] for i in range(n)]
        actual = f(f(x))
        for a,b in product(range(n),repeat=2):
            expected = tr(mm(mm(mm(ls[a],ls[p]),ls[q]),ls[b]))
            need(actual[a][b] == expected, 'F-squared contraction failed')
    # Unnormalized pair-support partial transpose = F composed with transpose.
    # Also the overlap of the two unnormalized triple embeddings is F.
    for a,k,i,b in product(range(n),repeat=4):
        overlap = sum(t[a][i][j]*t[b][j][k] for j in range(n))
        fentry = sum(t[j][a][i]*t[j][b][k] for j in range(n))
        need(overlap == fentry, 'Neighboring-embedding overlap failed')
        pt = sum(t[j][a][b]*t[j][i][k] for j in range(n))
        # Compute transpose-composition separately by applying F to |b><i|.
        x = [[int(r==b and c==i) for c in range(n)] for r in range(n)]
        need(pt == f(x)[a][k], 'Partial-transpose realignment failed')
    return {'dimension': n, 'four_trace_block_cases': n**4,
            'F_squared_coefficients': n**4, 'overlap_coefficients': n**4,
            'partial_transpose_coefficients': n**4, 'passed': True}


def main():
    d = 196883
    s2 = Q(1,3)
    kappa = Q(4620)-2*s2
    cubic_trace = Q(900)-3*s2
    alpha, beta = Q(166)-2*s2, Q(-116)
    u, v = Q(52)+166*s2-s2*s2, Q(52)-116*s2
    need((kappa,cubic_trace,alpha,beta,u,v)==
         (Q(13858,3),Q(899),Q(496,3),Q(-116),Q(965,9),Q(40,3)),
         'Projected trace coefficients mismatch')
    # Check the symmetric polynomial on the two distinguished subspaces.
    need(kappa*kappa == (alpha+beta)*kappa + (u+v)+u*d,
         'F^2 scalar sector mismatch')
    need(cubic_trace*cubic_trace == (alpha+beta)*cubic_trace+alpha*kappa+u+v,
         'F^2 multiplication sector mismatch')
    for z in [Q(155,3),Q(-7,3)]:
        need(z*z == (alpha+beta)*z + u+v, 'Symmetric polynomial root mismatch')
    for z in [Q(845,3),Q(-1,3)]:
        need(z*z == (alpha-beta)*z + u-v, 'Skew polynomial root mismatch')
    ns, na = d*(d+1)//2, d*(d-1)//2
    remaining = ns-1-d
    plus = (Q(d)*kappa/2-kappa-cubic_trace*d+Q(7,3)*remaining)/54
    aminus = (-Q(d)*kappa/2+Q(1,3)*na)/282
    need(plus.denominator == aminus.denominator == 1, 'Nonintegral multiplicity')
    mult = [1,d,int(plus),remaining-int(plus),int(aminus),na-int(aminus)]
    need(mult==[1,196883,842609326,18538750076,21296876,19360062527],
         'Spectral multiplicities mismatch')
    lam = [kappa,Q(899),Q(155,3),Q(-7,3),Q(845,3),Q(-1,3)]
    eig = [x/kappa for x in lam]
    eta = [1,1,1,1,-1,-1]
    need(sum(mult)==d*d, 'Total multiplicity mismatch')
    need(sum(m*r for m,r in zip(mult,eig))==0, 'Channel superoperator trace mismatch')
    need(sum(m*r*r for m,r in zip(mult,eig))==d, 'Channel HS norm mismatch')
    pt = [a*b for a,b in zip(eta,eig)]
    need(len(set(pt))==6, 'Partial transpose has spectral collision')
    need(set(pt[:4]).isdisjoint(pt[4:]), 'Transpose parity not recoverable spectrally')
    pt_gap = min(abs(a-b) for a in pt[:4] for b in pt[4:])
    need(pt_gap==Q(8,13858), 'Spectral parity gap mismatch')
    contraction = max(abs(r) for r in eig[1:])
    gap = 1-contraction
    need(gap==Q(11161,13858), 'Parent Hamiltonian gap mismatch')
    pair = [2+2*a*r-4*r*r for a,r in zip(eta,eig)]
    need(pair[0]==0 and min(pair[1:])==Q(3132,1681), 'Pair Hessian minimum mismatch')
    cubic = [3+6*a*r for a,r in zip(eta,eig)]
    need(min(cubic[1:])==Q(108,41), 'Cubic Hessian minimum mismatch')
    # I-sector cubic norm is 9, but its variance is zero; only traceless sectors used.
    chain4 = gap*(1-Q(1,d))/2
    xyz = [[[int(len({i,j,k})==3) for k in range(3)] for j in range(3)] for i in range(3)]
    generic = [[[0 for _ in range(4)] for _ in range(4)] for _ in range(4)]
    for a,b,c in combinations_with_replacement(range(4),3):
        for i,j,k in set(permutations((a,b,c))):
            generic[i][j][k]=(a+1)*(c+2)-(b+1)**2
    report = {
      'status':'PASS within stated scope',
      'scope':['Exact rational consequences of cited Monster trace identities',
               'General tensor index identities on dimensions 3 and 4',
               'Not a full Monster construction, independent theorem review, or novelty audit'],
      'dimension':d, 'kappa':str(kappa), 'projected_cubic_trace':str(cubic_trace),
      'channel_eigenvalues':[str(r) for r in eig], 'multiplicities':mult,
      'partial_transpose_eigenvalues_of_P':[str(r) for r in pt],
      'partial_transpose_parity_gap':str(pt_gap),
      'parent_gap':str(gap), 'parent_gap_decimal':float(gap),
      'pair_quadratic_coefficients':[str(r) for r in pair],
      'pair_local_coefficient':'12528/(1681*pi^2)',
      'pair_local_coefficient_decimal':12528/(1681*math.pi**2),
      'pair_local_radius':'operator norm of traceless H at most pi/4',
      'pair_distance_prefactor_decimal':math.sqrt(1681*math.pi**2/12528),
      'cubic_quadratic_coefficients_traceless':[str(r) for r in cubic[1:]],
      'four_site_energy_lower_bound':str(chain4),
      'reality_loss_global_prefactor':str(Q(4,d)/(pt_gap**2)),
      'toy_contractions':[tensor_checks(xyz),tensor_checks(generic)],
    }
    print(json.dumps(report,indent=2,sort_keys=True))

if __name__=='__main__':
    main()
