#!/usr/bin/env python3
"""Small numerical checks for general tensor identities, not the Monster itself.

Requires Python 3.10+ and NumPy. Uses only local dimensions 3 and 4 and
matrices of size at most 256 x 256. No network, random search, or large simulation.
The toy algebras need not have the Monster's exact unitary stabilizer.
"""
from __future__ import annotations
import json
import math
import numpy as np


def need(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def close(a, b, message: str, atol: float = 2e-10) -> float:
    error = float(np.linalg.norm(np.asarray(a) - np.asarray(b)))
    need(error <= atol, f'{message}: error {error} exceeds {atol}')
    return error


def exp_i(h: np.ndarray, t: float = 1.0) -> np.ndarray:
    vals, vecs = np.linalg.eigh(h)
    return (vecs * np.exp(1j * t * vals)) @ vecs.conj().T


def run_toy(n: int) -> dict:
    # Orthogonal projection of coordinatewise multiplication on R^n onto sum=0.
    d = n - 1
    basis = np.zeros((n, d))
    for j in range(d):
        basis[:j+1, j] = 1 / math.sqrt((j+1)*(j+2))
        basis[j+1, j] = -(j+1) / math.sqrt((j+1)*(j+2))
    tensor = np.einsum('ai,aj,ak->ijk', basis, basis, basis)
    kappa = (n-2) / n
    w = tensor.reshape(d, d*d).T / math.sqrt(kappa)
    p = w @ w.T
    channel = sum(np.kron(li, li) for li in tensor) / kappa
    left, right = np.kron(w, np.eye(d)), np.kron(np.eye(d), w)
    tau = tensor.reshape(-1) / math.sqrt(d*kappa)
    h3 = 2*np.eye(d**3) - left@left.T - right@right.T
    swap = np.eye(d*d).reshape(d,d,d,d).transpose(1,0,2,3).reshape(d*d,d*d)
    pt = p.reshape(d,d,d,d).transpose(0,3,2,1).reshape(d*d,d*d)
    errors = {
        'isometry': close(w.T@w, np.eye(d), 'isometry'),
        'recoupling': close(left.T@right, channel, 'neighbor overlap'),
        'partial_transpose': close(pt, channel@swap, 'partial transpose'),
        'ground_vector': close(h3@tau, np.zeros(d**3), 'ground vector'),
        'normalization': close(np.vdot(tau,tau), 1, 'normalization'),
    }
    evalues, evectors = np.linalg.eigh(channel)
    need(np.sum(abs(evalues-1)<1e-9)==1, 'Fixed subspace not one-dimensional')
    contraction = max(abs(x) for x in evalues if abs(x-1)>1e-9)
    gap = 1-contraction
    hvalues = np.linalg.eigvalsh(h3)
    need(np.sum(abs(hvalues)<1e-9)==1, 'Ground space not one-dimensional')
    errors['parent_gap'] = close(hvalues[1], gap, 'parent gap')
    rho2 = tau.reshape(d*d,d) @ tau.reshape(d*d,d).T
    errors['pair_marginal'] = close(rho2,p/d,'pair marginal')
    errors['single_marginal'] = close(w.T@w/d,np.eye(d)/d,'single marginal')
    rng = np.random.default_rng(174+n)
    response_checks = []
    for kind in ['symmetric', 'imaginary_skew', 'general_hermitian']:
        x = rng.normal(size=(d,d))
        s, a = (x+x.T)/2, 1j*(x-x.T)/2
        h = s if kind=='symmetric' else a if kind=='imaginary_skew' else s+a
        h -= np.trace(h)*np.eye(d)/d
        h = h / np.linalg.norm(h,ord=2) * 0.6  # safely within pi/4
        eh = (channel@h.reshape(-1)).reshape(d,d)
        eht = (channel@h.T.reshape(-1)).reshape(d,d)
        k = np.kron(h,np.eye(d))+np.kron(np.eye(d),h)
        direct = np.trace(w.T@k@(np.eye(d*d)-p)@k@w).real/d
        formula = (2*np.trace(h@h)+2*np.trace(h@eht)-4*np.trace(eh@eh)).real/d
        close(direct,formula,'pair quadratic identity')
        u = exp_i(h)
        u2 = np.kron(u,u)
        epsilon = 1-np.trace(p@u2@p@u2.conj().T).real/d
        psi = np.kron(u2,u)@tau
        energy = float(np.vdot(psi,h3@psi).real)
        cubic = float(1-abs(np.vdot(tau,psi))**2)
        close(energy,2*epsilon,'energy/leakage identity')
        need(epsilon+1e-10 >= (4/math.pi**2)*direct,'finite-radius sine bound')
        need(epsilon <= cubic+1e-10,'lower loss comparison')
        need(cubic <= 2*epsilon/gap+1e-10,'upper loss comparison')
        step = 2e-4
        small_u = exp_i(h,step)
        small_u2 = np.kron(small_u,small_u)
        small_leak = 1-np.trace(p@small_u2@p@small_u2.conj().T).real/d
        finite_estimate = small_leak/step**2
        need(abs(finite_estimate-direct)<2e-6,'quadratic finite difference')
        response_checks.append({'sector':kind, 'quadratic':float(direct),
            'finite_difference':float(finite_estimate), 'finite_loss':float(epsilon),
            'energy_identity_error':float(abs(energy-2*epsilon))})
    # The pure triple cannot be placed on both overlapping triples without conflict.
    aa = np.kron(tau[:,None],np.eye(d))
    bb = np.kron(np.eye(d),tau[:,None])
    errors['overlapping_triple_inner_product'] = close(aa.T@bb,np.eye(d)/d,
                                                     'four-site triple overlap')
    h4 = (3*np.eye(d**4)-np.kron(p,np.eye(d*d))
          -np.kron(np.eye(d),np.kron(p,np.eye(d)))-np.kron(np.eye(d*d),p))
    bottom = float(np.linalg.eigvalsh(h4)[0])
    lower = gap*(1-1/d)/2
    need(bottom+1e-10>=lower,'four-site frustration bound')
    return {'dimension':d, 'largest_matrix_dimension':d**4,
        'errors':errors, 'parent_gap':float(gap), 'response_checks':response_checks,
        'four_site_ground_energy':bottom, 'four_site_lower_bound':float(lower),
        'exact_Monster_stabilizer_tested':False, 'passed':True}


def main() -> None:
    print(json.dumps({'status':'PASS within stated scope',
        'scope':'Numerical checks on two small non-Monster symmetric tensors only',
        'numpy_version':np.__version__, 'toys':[run_toy(n) for n in (4,5)]},
        sort_keys=True,indent=2))


if __name__=='__main__':
    main()
