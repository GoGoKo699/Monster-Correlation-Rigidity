# Monster bipartite-correlation checkpoint

Start with **Monster_Bipartite_Correlations.md**.

This checkpoint derives a bipartite mixed-state encoding of Monster symmetry, a unique three-register parent ground state with an exact gap, and a two-query local membership test from established Griess trace identities. It does not claim publication novelty, efficient circuits, or a useful explicit global gate-distance theorem.

## Contents

- `Monster_Bipartite_Correlations.md`: normalization, proofs, sources and claim boundaries.
- `verify_exact.py`: standard-library exact arithmetic and small integer tensor checks.
- `verification_exact.json`: actual exact-check output, also reproduced under `python -O`.
- `verify_toy.py`: NumPy checks on dimensions 3 and 4 only.
- `verification_toy.json`: actual small numerical check output.
- `verification_previous_rerun.json`: successful rerun of the previous local verifier.
- `previous/`: unchanged contents of the previously supplied local-rigidity checkpoint.
- `manifest.json`: SHA-256 checksums of all other packaged files.

## Reproduce

```bash
python verify_exact.py
python -O verify_exact.py
OPENBLAS_NUM_THREADS=1 python verify_toy.py
python previous/verify_monster_local.py
```

All checks are local and small. Exact results are conditional on the cited trace identities. Passing the checks is not independent mathematical review or a novelty audit. Floating-point output may vary slightly across NumPy and BLAS versions.
