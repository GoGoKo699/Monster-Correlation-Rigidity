#!/usr/bin/env python3
"""Exact arithmetic checks for the Monster correlation local-rigidity note.

Python 3.10+, standard library only. No network or large matrices are used.
Run: python verify_monster_local.py

Scope: verifies arithmetic conditional on quoted Norton--Matsuo identities,
and general tensor-contraction identities on small integer examples. This
is NOT a construction of the Monster tensor, a check of every literature
input, an independent proof of the full theorem, or a novelty assessment.
"""
from __future__ import annotations

from fractions import Fraction as Q
from itertools import combinations, combinations_with_replacement, permutations
import json
import math

Matrix = list[list[int]]
Tensor = list[list[list[int]]]


def require(condition: bool, message: str) -> None:
    """Checks remain active under python -O and -OO."""
    if not condition:
        raise RuntimeError(message)


def zeros(n: int) -> Matrix:
    return [[0 for _ in range(n)] for _ in range(n)]


def add(a: Matrix, b: Matrix, sign: int = 1) -> Matrix:
    return [[x + sign * y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def mul(a: Matrix, b: Matrix) -> Matrix:
    n = len(a)
    return [[sum(a[i][k] * b[k][j] for k in range(n))
             for j in range(n)] for i in range(n)]


def inner(a: Matrix, b: Matrix) -> int:
    return sum(x * y for ar, br in zip(a, b) for x, y in zip(ar, br))


def skew_basis(n: int) -> list[Matrix]:
    result = []
    for i, j in combinations(range(n), 2):
        a = zeros(n)
        a[i][j], a[j][i] = 1, -1
        result.append(a)
    return result


def tensor_checks(t: Tensor) -> dict[str, int | bool]:
    n = len(t)
    matrices = [[[t[i][j][k] for k in range(n)] for j in range(n)]
                for i in range(n)]
    gram = [[sum(t[i][j][k] * t[l][j][k]
                 for j in range(n) for k in range(n))
             for l in range(n)] for i in range(n)]

    def f(a: Matrix) -> Matrix:
        out = zeros(n)
        for li in matrices:
            out = add(out, mul(mul(li, a), li))
        return out

    basis = skew_basis(n)
    tests = basis + [add(a, b) for a, b in combinations(basis, 2)]
    for a in tests:
        derivative_sq = 0
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    value = sum(a[i][r] * t[r][j][k]
                                + a[j][r] * t[i][r][k]
                                + a[k][r] * t[i][j][r] for r in range(n))
                    derivative_sq += value * value
        single_leg_sq = sum(a[i][r] * a[i][s] * gram[r][s]
                            for i in range(n) for r in range(n) for s in range(n))
        require(derivative_sq == 3 * single_leg_sq - 6 * inner(a, f(a)),
                "Tensor-derivative contraction identity failed")

    for a in basis:
        for b in basis:
            require(inner(a, f(b)) == inner(f(a), b), "F is not self-adjoint")

    # Trace on skew matrices; these basis elements have squared norm two.
    trace_f = sum(Q(inner(a, f(a)), 2) for a in basis)
    trace_formula = sum(Q(sum(li[i][i] for i in range(n)) ** 2
                          - inner(li, li), 2) for li in matrices)
    require(trace_f == trace_formula, "Trace on the skew sector failed")

    # Verify F(X_ab) = [L_a,L_b] and the unital-extension block identity.
    # The toy extension uses s=1, not the Monster normalization s=1/sqrt(3).
    blocks = []
    for i, li in enumerate(matrices):
        r = zeros(n + 1)
        r[0][i + 1] = r[i + 1][0] = 1
        for j in range(n):
            for k in range(n):
                r[j + 1][k + 1] = li[j][k]
        blocks.append(r)
    for (i, j), x in zip(combinations(range(n), 2), basis):
        require(f(x) == add(mul(matrices[i], matrices[j]),
                            mul(matrices[j], matrices[i]), -1),
                "F(X_ab) commutator identity failed")
        comm = add(mul(blocks[i], blocks[j]), mul(blocks[j], blocks[i]), -1)
        require(all(comm[0][k] == comm[k][0] == 0 for k in range(n + 1)),
                "Unital extension has unexpected off-diagonal block")
        lower = [[comm[r + 1][s + 1] for s in range(n)] for r in range(n)]
        require(lower == add(f(x), x), "Unital-extension block identity failed")
    return {"dimension": n, "quadratic_identity_tests": len(tests),
            "self_adjointness_tests": len(basis) ** 2,
            "commutator_tests": len(basis), "all_passed": True}


def main() -> None:
    d, central_charge = 196883, 24
    full_d = d + 1
    # Matsuo, arXiv:math/0007169, Corollary 4.1, printed page 16.
    trace2_coefficient = Q(4620)
    general_trace2 = -Q(2 * (5 * central_charge ** 2 - 88 * full_d
                              + 2 * central_charge * full_d),
                       central_charge * (5 * central_charge + 22))
    require(general_trace2 == trace2_coefficient, "General trace-2 formula mismatch")
    s_squared = Q(1, 3)
    kappa = trace2_coefficient - 2 * s_squared
    # Fourth-order coefficients: 166, -116, 166.
    beta = Q(166 - (-116))
    lambda_high = 3 * kappa + 6 * s_squared
    lambda_low = lambda_high - 6 * beta
    gamma_low, gamma_high = lambda_low / kappa, lambda_high / kappa
    require(kappa == Q(13858, 3), "Tensor normalization mismatch")
    require((lambda_low, lambda_high) == (Q(12168), Q(13860)), "Spectrum mismatch")
    require(gamma_low == Q(108, 41), "Lowest normalized coefficient mismatch")
    require(gamma_high == Q(20790, 6929), "Highest normalized coefficient mismatch")

    skew_dimension = d * (d - 1) // 2
    trace_f = -Q(d) * kappa / 2
    projector_rank = (trace_f + s_squared * skew_dimension) / beta
    require(projector_rank.denominator == 1, "Projector rank is not integral")
    low_mult = int(projector_rank)
    high_mult = skew_dimension - low_mult
    require((low_mult, high_mult) == (21296876, 19360062527), "Multiplicity mismatch")
    require(low_mult > 0 and high_mult > 0, "Both coefficients must occur")
    require((beta - s_squared) * low_mult - s_squared * high_mult == trace_f,
            "Spectral trace cross-check failed")

    xyz = [[[int(len({i, j, k}) == 3) for k in range(3)]
            for j in range(3)] for i in range(3)]
    generic = [[[0 for _ in range(4)] for _ in range(4)] for _ in range(4)]
    for i, j, k in combinations_with_replacement(range(4), 3):
        value = (i + 1) * (k + 2) - (j + 1) ** 2
        for a, b, c in set(permutations((i, j, k))):
            generic[a][b][c] = value
    local_c = 4 * float(gamma_low) / math.pi ** 2
    report = {
        "status": "PASS within the explicitly limited verification scope",
        "scope": ["Exact rational arithmetic conditional on literature inputs",
                  "Small integer tensor identities, not the Monster tensor",
                  "No global robustness, circuit-efficiency, or novelty verification"],
        "source": "Matsuo, arXiv:math/0007169, Corollary 4.1 and Section 1.1",
        "dimension": d,
        "tensor_norm_squared": str(d * kappa),
        "kappa": str(kappa),
        "commutator_projector_scale": str(beta),
        "orthogonal_quadratic_coefficients": [str(gamma_low), str(gamma_high)],
        "multiplicities": [low_mult, high_mult],
        "local_loss_lower_bound_coefficient": "432/(41*pi^2)",
        "local_loss_lower_bound_coefficient_decimal": local_c,
        "local_distance_upper_bound_prefactor_decimal": math.sqrt(1 / local_c),
        "toy_tensor_checks": {"xyz": tensor_checks(xyz),
                              "generic_symmetric_dimension_4": tensor_checks(generic)},
    }
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
