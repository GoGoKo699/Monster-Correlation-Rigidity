# License handling for the local repository seed

The owner has not yet selected a root license for this new repository. No LICENSE file is supplied by this seed. When importing into the owner's repository, preserve its existing LICENSE unchanged.

The four prior checkpoint ZIPs and historical notes are retained as provenance, not relicensed copies of their external references. The included numerical character excerpt is a declared transcription of mathematical table data from a pinned ATLAS-derived GAP source; retain that attribution and its metadata. No original GAP source file or third-party paper is bundled.

Do not infer a license choice from licenses in the owner's unrelated repositories.
