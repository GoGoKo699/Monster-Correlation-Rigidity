#!/usr/bin/env python3
"""Replay unchanged earlier verifiers in a temporary extraction, with hash checks."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile
import zipfile


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    archive = Path(__file__).resolve().parent/'previous'/'Monster_Bipartite_Correlations_Checkpoint.zip'
    records: dict[str, object] = {}
    with tempfile.TemporaryDirectory(prefix='monster_previous_') as temporary:
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                parts = PurePosixPath(name)
                if parts.is_absolute() or '..' in parts.parts:
                    raise RuntimeError('Unsafe archive member')
            z.extractall(temporary)
        root = Path(temporary)/'Monster_Bipartite_Correlations'
        manifest = json.loads((root/'manifest.json').read_text())
        for entry in manifest['files']:
            payload = (root/entry['path']).read_bytes()
            if len(payload) != entry['bytes'] or digest(payload) != entry['sha256']:
                raise RuntimeError(f"Prior archive manifest mismatch: {entry['path']}")
        environment = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
        scripts = {
            'prior_exact': ('verify_exact.py', 'verification_exact.json'),
            'prior_toy': ('verify_toy.py', 'verification_toy.json'),
            'first_checkpoint': ('previous/verify_monster_local.py', 'previous/verification.json'),
        }
        for key, (script, saved) in scripts.items():
            outcome = subprocess.run([sys.executable, script], cwd=root, env=environment,
                                     check=True, capture_output=True, timeout=35)
            report = json.loads(outcome.stdout)
            records[key] = {
                'exit_code': outcome.returncode,
                'stderr': outcome.stderr.decode(),
                'report': report,
                'stdout_sha256': digest(outcome.stdout),
                'byte_identical_to_saved_report': outcome.stdout == (root/saved).read_bytes(),
            }
        optimized = subprocess.run([sys.executable, '-O', 'verify_exact.py'], cwd=root,
                                   env=environment, check=True, capture_output=True, timeout=35)
        if digest(optimized.stdout) != records['prior_exact']['stdout_sha256']:
            raise RuntimeError('Prior exact verifier changed output under optimization')
    print(json.dumps({
        'status': 'PASS within the prior verifiers\' stated scopes',
        'prior_archive_sha256': digest(archive.read_bytes()),
        'prior_manifest_files_checked': len(manifest['files']),
        'prior_exact_optimized_output_identical': True,
        'reruns': records,
        'scope': 'Integrity and replay only; not an independent mathematical review or full Monster simulation',
    }, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
