# Monster correlation rigidity: global small-loss checkpoint

Start with **[Monster_Global_Rounding.md](Monster_Global_Rounding.md)**.

The new written result removes the prior proximity promise from the bipartite symmetry test: for the true ideal rejection probability epsilon <= 10^-25, normalized Frobenius distance to phase times a Monster operation is at most sqrt(1681*pi^2/12528)*sqrt(epsilon) < 1.151*sqrt(epsilon).

The proof uses unitary Virasoro central-charge restrictions, the finite Ising-axis geometry, a cubic critical-value gap, exact character moments, and the previous local pair-test bound. Its threshold is not experimentally useful. Novelty, efficient probe access, and independent proof review are not established.

## Files

- `Monster_Global_Rounding.md`: full proof, input normalization, provenance, claim limits, and next mathematical bottleneck.
- `monster_character_excerpt.json`: pinned source metadata and transcribed ATLAS/GAP character/centralizer arrays; not a byte-identical source archive.
- `verify_global.py` and `verification_global.json`: 34 deterministic exact scalar/character checks, plus readable decimal values. Standard library only.
- `rerun_previous.py` and `verification_previous_rerun.json`: hash-checked replay of the previous exact and small NumPy toy verifiers in a temporary directory.
- `previous/Monster_Bipartite_Correlations_Checkpoint.zip`: unchanged prior archive, containing the earlier bipartite and local checkpoints.
- `manifest.json`: payload sizes and SHA-256 hashes. Integrity only, not a theorem verification.

Run:

```bash
python verify_global.py
python -O verify_global.py
python rerun_previous.py
```

The previous toy replay requires NumPy. Normal, `-O`, and `-OO` runs of the new verifier produced byte-identical outputs. The three replayed earlier reports also matched their stored outputs byte-for-byte in the current environment. No full Monster tensor was constructed or simulated.
