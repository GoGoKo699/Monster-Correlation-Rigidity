#!/usr/bin/env python3
"""Reproduce scalar/character checks for the global Monster rounding checkpoint.

Standard library only. These checks do not construct the Monster tensor, prove
VOA classification inputs, independently review the proof, or establish novelty.
No asserts are used: checks remain active with python -O and python -OO.
"""
from __future__ import annotations

import hashlib
import json
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path
from typing import Iterable

DATA_SHA256 = '70218f4f87e67896a64c8577b7a86fb0c46cebe3c71678397a7654b8ef0596e0'
CHECKS: list[str] = []


def require(condition: bool, label: str) -> None:
    if not condition:
        raise RuntimeError(f'Check failed: {label}')
    CHECKS.append(label)


def poly_add(a: Iterable[F], b: Iterable[F]) -> tuple[F, ...]:
    aa, bb = tuple(a), tuple(b)
    out = [F(0)] * max(len(aa), len(bb))
    for i, x in enumerate(aa):
        out[i] += x
    for i, x in enumerate(bb):
        out[i] += x
    while len(out) > 1 and out[-1] == 0:
        out.pop()
    return tuple(out)


def poly_scale(a: Iterable[F], c: F) -> tuple[F, ...]:
    return poly_add(tuple(c*x for x in a), (F(0),))


def poly_mul(a: Iterable[F], b: Iterable[F]) -> tuple[F, ...]:
    aa, bb = tuple(a), tuple(b)
    out = [F(0)]*(len(aa)+len(bb)-1)
    for i, x in enumerate(aa):
        for j, y in enumerate(bb):
            out[i+j] += x*y
    return poly_add(out, (F(0),))


def poly_diff(a: Iterable[F]) -> tuple[F, ...]:
    aa = tuple(a)
    return tuple(F(i)*aa[i] for i in range(1, len(aa))) or (F(0),)


def atan_bounds(x: F, terms: int = 15) -> tuple[F, F]:
    """Exact alternating-series interval for arctan(x), 0<x<1."""
    if not F(0) < x < F(1) or terms < 1:
        raise ValueError('arctan series requires 0<x<1 and terms>=1')
    total = sum((F((-1)**k, 2*k+1)*x**(2*k+1)
                 for k in range(terms)), F(0))
    adjacent = total + F((-1)**terms, 2*terms+1)*x**(2*terms+1)
    return min(total, adjacent), max(total, adjacent)


def dec(q: F | int) -> Decimal:
    q = F(q)
    return Decimal(q.numerator)/Decimal(q.denominator)


def main() -> None:
    data_path = Path(__file__).resolve().with_name('monster_character_excerpt.json')
    raw = data_path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == DATA_SHA256,
            'Pinned character-excerpt SHA-256')
    data = json.loads(raw)
    centralizers, chi = data['centralizers'], data['character']
    require(len(centralizers) == len(chi) == 194, '194 character-table columns')
    require(all(type(x) is int and x > 0 for x in centralizers),
            'Centralizer orders are positive integers')
    require(all(type(x) is int for x in chi), 'Character entries are integers')
    require(chi[0] == 196883, 'Character degree')
    group_order = centralizers[0]
    require(all(group_order % z == 0 for z in centralizers),
            'Each class centralizer divides group order')
    moments = [sum((F(x**m, z) for x, z in zip(chi, centralizers)), F(0))
               for m in range(5)]
    require(moments == [F(1), F(0), F(1), F(1), F(6)],
            'Exact character moments m=0,...,4 equal 1,0,1,1,6')

    # Symbolic polynomial identities for n=||e||^2, u=b^2 and r=b*lambda.
    n = (F(0), F(1))
    u = (F(0), F(1), F(-1, 3))
    r = (F(1), F(-2, 3))
    require(poly_add(u, poly_scale(poly_mul(n, n), F(1, 3))) == n,
            'Scalar idempotent condition: u+n^2/3=n')
    require(poly_add(poly_mul(r, r), poly_scale(u, F(4, 3))) == (F(1),),
            'Inverse parameter condition: r^2+(4/3)u=1')
    deriv_num = poly_add(poly_mul(poly_diff(r), u),
                         poly_scale(poly_mul(r, poly_diff(u)), F(-1, 2)))
    require(deriv_num == (F(-1, 2),),
            'Cubic critical value derivative numerator is -1/2')

    n_axis = F(1, 16)
    b_axis_sq = n_axis - n_axis*n_axis/F(3)
    require(b_axis_sq == F(141, 2304), 'Axis traceless coefficient squared')
    maximum_sq = (1-2*n_axis/3)**2/b_axis_sq
    n_next = F(7, 80)
    next_sq = (1-2*n_next/3)**2/(n_next-n_next*n_next/3)
    require(maximum_sq == F(46**2, 141), 'Maximum cubic value squared')
    require(next_sq == F(226**2, 4893), 'Next allowed critical value squared')
    require(maximum_sq > F(19, 5)**2 and next_sq < F(33, 10)**2,
            'Top critical-value gap exceeds 1/2')
    require(maximum_sq < 16 and F(36**2, 141) > 9,
            'Coarse bounds M_f<4 and 36/sqrt(141)>3')
    radius = F(1, 10)
    require(3 - 3*radius**2 - 4*radius > 2,
            'Radius-1/10 cubic drop coefficient exceeds 2')
    require(2*radius**2 == F(1, 50), 'Global superlevel deficit threshold')

    # Peirce spectrum converted to the traceless tangent normalization.
    peirce = [F(0), F(1, 4), F(1, 32)]
    tangent_numerators = [48*x - 1 for x in peirce]
    require(tangent_numerators == [F(-1), F(11), F(1, 2)],
            'Tangent multiplication eigenvalue numerators')
    hessian_numerators = [6*x - 3*46 for x in tangent_numerators]
    require(hessian_numerators == [F(-144), F(-72), F(-135)],
            'Negative sphere Hessian numerators')

    q_values = {F(1), F(0), F(1, 8), F(1, 64), F(13, 256),
                F(1, 32), F(3, 128), F(5, 256)}
    alphabet = sorted((48*q-1)/47 for q in q_values)
    gap = min(b-a for a, b in zip(alphabet, alphabet[1:]))
    require(gap == F(3, 752), 'Normalized axis inner-product alphabet gap')
    offdiag_max = max(x for x in alphabet if x != 1)
    require(offdiag_max == F(5, 47), 'Largest allowed off-diagonal inner product')
    require(2 - 2*offdiag_max == F(84, 47) > 1,
            'Squared minimum axis separation exceeds 1')

    d = 196883
    kappa = F(13858, 3)
    delta = F(11161, 13858)
    reality = F(48011041, 787532)
    require(reality < 61 and delta > F(4, 5),
            'Prior reality and parent-gap coarse rational bounds')
    # A0=3sqrt(K_R)+2/sqrt(Delta)<26, then C_T<800000.
    require(reality < F(63, 8)**2, 'sqrt(K_R)<63/8')
    require(F(4)/delta < F(9, 4)**2, '2/sqrt(Delta)<9/4')
    require(3*F(63, 8)+F(9, 4) < 26, 'Tensor-transfer factor A0<26')
    require(d*kappa*26**2 < 800000**2, 'Tensor-transfer factor C_T<800000')

    epsilon0 = F(1, 10**25)
    sqrt_eps_upper = F(1, 3*10**12)
    require(epsilon0 < sqrt_eps_upper**2, 'sqrt(epsilon0)<1/(3*10^12)')
    deficit_upper = 800000*sqrt_eps_upper
    h = F(1, 2000)
    require(deficit_upper < 2*h*h < F(1, 50),
            'Uniform axis deficit yields radius h=1/2000')
    require(2*h < gap and (2*h)**2 < F(84, 47),
            'Rounding is injective and preserves exact inner-product alphabet')
    require(d < 444**2 and reality < 64,
            'sqrt(d)<444 and sqrt(K_R)<8')
    op_bound = 444*(h+8*sqrt_eps_upper)
    require(op_bound < F(1, 4), 'Rounded operation is within operator norm 1/4')

    # Machin identity pi=16 atan(1/5)-4 atan(1/239), exact series bounds.
    lo5, hi5 = atan_bounds(F(1, 5))
    lo239, hi239 = atan_bounds(F(1, 239))
    pi_lo, pi_hi = 16*lo5-4*hi239, 16*hi5-4*lo239
    require(F(3) < pi_lo < pi_hi < F(22, 7), 'Consistent rational pi bounds')
    require(F(1681, 12528)*pi_hi*pi_hi < F(1151, 1000)**2,
            'Local square-root prefactor is less than 1.151')

    with localcontext() as ctx:
        ctx.prec = 55
        maximum = dec(maximum_sq).sqrt()
        next_value = dec(next_sq).sqrt()
        a0 = 3*dec(reality).sqrt()+2/dec(delta).sqrt()
        transfer = dec(d*kappa).sqrt()*a0
        pi_mid = dec((pi_lo+pi_hi)/2)
        prefactor = (dec(F(1681, 12528))*pi_mid*pi_mid).sqrt()
        # Stable log expression: needed zero-failure N ≈ -log(.05)/epsilon0.
        ideal_trials = -(Decimal(1)/20).ln()/dec(epsilon0)
        numerics = {key: str(value) for key, value in {
            'maximum_cubic': maximum,
            'next_allowed_critical_upper_bound': next_value,
            'critical_gap_lower_bound': maximum-next_value,
            'tensor_transfer_factor_C_T': transfer,
            'local_distance_prefactor': prefactor,
            'coarse_operator_radius': dec(op_bound),
            'zero_rejection_trials_95_percent_asymptotic': ideal_trials,
        }.items()}

    report = {
        'status': 'PASS within stated scope',
        'scope': [
            'Exact scalar identities and rational inequalities used in the written proof',
            'Character moments of pinned transcribed ATLAS/GAP data',
            'No full Monster simulation, independent proof review, or novelty determination',
        ],
        'checks_passed': len(CHECKS),
        'checks': CHECKS,
        'character_data_sha256': DATA_SHA256,
        'character_moments_0_through_4': [str(x) for x in moments],
        'axis_inner_product_alphabet': [str(x) for x in alphabet],
        'axis_inner_product_gap': str(gap),
        'small_loss_threshold': str(epsilon0),
        'distance_bound': 'sqrt(1681*pi^2/12528)*sqrt(epsilon), with epsilon<=1e-25',
        'prior_proximity_promise': False,
        'trusted_fixed_unitary_and_probe_model': True,
        'decimal_values_for_readability_not_certificates': numerics,
    }
    print(json.dumps(report, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
